package com.avila.api.service;

import com.avila.api.dto.ProductoRequestDTO;
import com.avila.api.dto.ProductoResponseDTO;
import com.avila.api.exception.NotFoundException;
import com.avila.api.model.Producto;
import com.avila.api.repository.ProductoRepository;
import org.springframework.stereotype.Service;


import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProductoService {

    private final ProductoRepository repository;

    public ProductoService(ProductoRepository repository) {
        this.repository = repository;
    }

    public ProductoResponseDTO crear(ProductoRequestDTO dto) {
        Producto producto = new Producto();
        producto.setNombreProducto(dto.getNombreProducto());
        producto.setPrecio(dto.getPrecio());

        Producto guardado = repository.guardar(producto);

        return new ProductoResponseDTO(
                guardado.getId(),
                guardado.getNombreProducto(),
                guardado.getPrecio()
        );
    }

    public List<ProductoResponseDTO> listar() {
        return repository.listar().stream()
                .map(p -> new ProductoResponseDTO(p.getId(), p.getNombreProducto(), p.getPrecio()))
                .collect(Collectors.toList());
    }

    public ProductoResponseDTO obtener(Long id) {
        Producto p = repository.buscarPorId(id)
                .orElseThrow(() -> new NotFoundException("Producto no encontrado"));

        return map(p);
    }

    public ProductoResponseDTO actualizar(Long id, ProductoRequestDTO dto) {
        Producto p = repository.buscarPorId(id)
                .orElseThrow(() -> new NotFoundException("Producto no encontrado"));

        p.setNombreProducto(dto.getNombreProducto());
        p.setPrecio(dto.getPrecio());

        repository.actualizar(id, p);

        return map(p);
    }

    public void eliminar(Long id) {
        repository.buscarPorId(id)
                .orElseThrow(() -> new NotFoundException("Producto no encontrado"));

        repository.eliminar(id);
    }

    private ProductoResponseDTO map(Producto p) {
        return new ProductoResponseDTO(p.getId(), p.getNombreProducto(), p.getPrecio());
    }

}
