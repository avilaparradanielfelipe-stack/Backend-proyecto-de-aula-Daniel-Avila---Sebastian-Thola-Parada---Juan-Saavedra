package com.avila.api.repository;

import com.avila.api.model.Producto;
import org.springframework.stereotype.Repository;

import java.util.*;

@Repository
public class ProductoRepository {

    private Map<Long, Producto> data = new HashMap<>();
    private Long idCounter = 1L;

    public Producto guardar(Producto usuario) {
        usuario.setId(idCounter++);
        data.put(usuario.getId(), usuario);
        return usuario;
    }

    public List<Producto> listar() {
        return new ArrayList<>(data.values());
    }

    public Optional<Producto> buscarPorId(Long id) {
        return Optional.ofNullable(data.get(id));
    }

    public Producto actualizar(Long id, Producto producto) {
        producto.setId(id);
        data.put(id, producto);
        return producto;
    }

    public void eliminar(Long id) {
        data.remove(id);
    }
}
