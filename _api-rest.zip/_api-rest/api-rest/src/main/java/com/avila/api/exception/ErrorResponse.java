package com.avila.api.exception;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
public class ErrorResponse {

    private String mensaje;
    private int status;
    private LocalDateTime fecha;

    public ErrorResponse(String mensaje, int status) {
        this.mensaje = mensaje;
        this.status = status;
        this.fecha = LocalDateTime.now();
    }

}
