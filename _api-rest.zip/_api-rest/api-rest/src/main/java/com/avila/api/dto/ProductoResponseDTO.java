package com.avila.api.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class ProductoResponseDTO {

    private Long id;
    private String nombreProducto;
    private Long precio;

}
