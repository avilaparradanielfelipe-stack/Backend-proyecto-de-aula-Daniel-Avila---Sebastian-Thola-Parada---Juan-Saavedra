package com.avila.api.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Producto {

    private Long id;
    private String nombreProducto;
    private Long precio;

}
