package com.avila.api.service;

import com.avila.api.dto.UsuarioRequestDTO;
import com.avila.api.dto.UsuarioResponseDTO;
import com.avila.api.exception.NotFoundException;
import com.avila.api.model.Usuario;
import com.avila.api.repository.UsuarioRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class UsuarioService {

    private final UsuarioRepository repository;

    public UsuarioService(UsuarioRepository repository) {
        this.repository = repository;
    }

    public UsuarioResponseDTO crear(UsuarioRequestDTO dto) {
        Usuario usuario = new Usuario();
        usuario.setNombre(dto.getNombre());
        usuario.setEmail(dto.getEmail());

        Usuario guardado = repository.guardar(usuario);

        return mapToResponse(guardado);
    }

    public List<UsuarioResponseDTO> listar() {
        return repository.listar()
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    public UsuarioResponseDTO obtenerPorId(Long id) {
        Usuario usuario = repository.buscarPorId(id)
                .orElseThrow(() -> new NotFoundException("Usuario no encontrado"));

        return mapToResponse(usuario);
    }

    public UsuarioResponseDTO actualizar(Long id, UsuarioRequestDTO dto) {
        Usuario existente = repository.buscarPorId(id)
                .orElseThrow(() -> new NotFoundException("Usuario no encontrado"));

        existente.setNombre(dto.getNombre());
        existente.setEmail(dto.getEmail());

        repository.actualizar(id, existente);

        return mapToResponse(existente);
    }

    public void eliminar(Long id) {
        repository.buscarPorId(id)
                .orElseThrow(() -> new NotFoundException("Usuario no encontrado"));

        repository.eliminar(id);
    }

    private UsuarioResponseDTO mapToResponse(Usuario usuario) {
        return new UsuarioResponseDTO(
                usuario.getId(),
                usuario.getNombre(),
                usuario.getEmail()
        );
    }
}