package com.avila.api.repository;


import com.avila.api.model.Usuario;
import org.springframework.stereotype.Repository;

import java.util.*;

@Repository
public class UsuarioRepository {

    private Map<Long, Usuario> data = new HashMap<>();
    private Long idCounter = 1L;

    public Usuario guardar(Usuario usuario) {
        usuario.setId(idCounter++);
        data.put(usuario.getId(), usuario);
        return usuario;
    }

    public List<Usuario> listar() {
        return new ArrayList<>(data.values());
    }

    public Optional<Usuario> buscarPorId(Long id) {
        return Optional.ofNullable(data.get(id));
    }

    public void eliminar(Long id) {
        data.remove(id);
    }

    public Usuario actualizar(Long id, Usuario usuario) {
        usuario.setId(id);
        data.put(id, usuario);
        return usuario;
    }
}
