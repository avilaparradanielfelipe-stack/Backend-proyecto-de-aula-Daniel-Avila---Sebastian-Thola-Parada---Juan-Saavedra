package com.avila.api.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductoRequestDTO {

    @NotBlank
    private String nombreProducto;

    @NotBlank
    private Long precio;
}
